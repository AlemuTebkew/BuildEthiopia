<?php

namespace App\Http\Controllers\UserSide;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Notifications\ThankUForDonation;
use Illuminate\Http\Request;
use League\CommonMark\Extension\CommonMark\Renderer\Block\ThematicBreakRenderer;

class DonationController extends Controller
{
    public function saveDonation(Request $request){

        $request->validate([

            'full_name'=>'required',
            'donation_amount'=>'required',

        ]);

        $user=User::create($request->all());
        $user->notify(new ThankUForDonation());
        return response()->json($user->load('zone'),201);
    }

    public function getDonation(){
        $per_page=request('per_page') ?? 10;
        return User::with('donated_for')->paginate($per_page);
    }
}
